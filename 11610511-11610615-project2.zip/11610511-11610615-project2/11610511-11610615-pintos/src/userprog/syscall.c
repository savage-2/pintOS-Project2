#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "userprog/process.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/off_t.h"
#include "kernel/list.h"

static void syscall_handler (struct intr_frame *);
int sys_exec(char *file_name);
int sys_open(char *name);
int sys_read(int size, void *buffer, int fd);
int sys_write(int size, void *buffer, int fd);
void sys_close(int fd);
void sys_exit(int status);


void
syscall_init (void)
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f)
{
  	int *p = f->esp;
	check_addr(p);

	switch (*p)
	{
		case SYS_HALT: 
			
			shutdown_power_off();
			break;

		case SYS_EXIT: 
			{
				int status = *(p+1);
				check_addr(p + 1);
				sys_exit(status);
				// thread_exit ();
				break;
			}

		case SYS_EXEC: 
			{
				char *fileName = *(p+1);
				check_addr(fileName);
				f->eax = sys_exec(fileName);
		 		break;
			}

		case SYS_WAIT: 
			{
				tid_t child_tid = (tid_t)*(p+1);
				f->eax = process_wait(child_tid);
				break;
			} 

		case SYS_CREATE: 
			{
				int ret;
				int size = *(p+5);
				char *name = *(p+4);
				check_addr(name);
				lock_acquire(&system_file_lock);
				ret = filesys_create(name, size);
				lock_release(&system_file_lock);
				f->eax = ret;
				break;
			}

		case SYS_REMOVE:
			{
				int name = *(p+1);
				check_addr(name);
				if (filesys_remove((char *)name) == NULL) {
					f->eax = false;
				}
				else {
					f->eax = true;
				}
				break;
			}

		case SYS_OPEN: 
			{
				int name = *(p+1);
				check_addr(name);
				f->eax = sys_open((char *)name);
				break;
			}

		case SYS_FILESIZE: 
			{
				int fd = *(p+1);
				lock_acquire(&system_file_lock);
				struct file_describer *fi = find_file(fd);
				f->eax = file_length (fi->ptr);
				lock_release(&system_file_lock);
				break;
			}

		case SYS_READ: 
			{
				int size = *(p+7);
				void *buffer = *(p+6);
				int fd = *(p+5);
				check_addr(buffer);
				f->eax = sys_read(size, buffer,fd);  
				break;
			}

		case SYS_WRITE:
			{
				int size = *(p+7);
				void *buffer = *(p+6);
				int fd = *(p+5);
				check_addr(buffer);
				f->eax = sys_write(size, buffer,fd); 
				break;
			}

		case SYS_SEEK: 
			{
				int fd = *(p+5);
				int pos = *(p+4);
				lock_acquire(&system_file_lock);
				struct file_describer *fi = find_file(pos);
				file_seek(fi->ptr, fd);
				lock_release(&system_file_lock);
				break;
			}

		case SYS_TELL:
			{
				int ret;
				int fd = *(p+1);
				lock_acquire(&system_file_lock);
				struct file_describer *fi = find_file(fd);
				ret = file_tell(fi->ptr);
				lock_release(&system_file_lock);
				f->eax = ret;
				break;
			}

		case SYS_CLOSE:
			{
				int fd = *(p+1);
				lock_acquire(&system_file_lock);
				sys_close(fd);
				lock_release(&system_file_lock);
				break;
			}
	}
}

/* check whether the thread has already exited
if it is still alive, allocated process_execute to execute */
int sys_exec(char *file_name)
{
	lock_acquire(&system_file_lock);
	if (file_name == NULL ) {
	      thread_exit();
	}
	char *remain = NULL;
	char * name = malloc (strlen(file_name)+1);
	strlcpy(name, file_name, strlen(file_name) + 1);
	struct file *f = filesys_open(strtok_r(name, " ", &remain)); 
	if (f == NULL)
	{
		lock_release(&system_file_lock);
		return -1;
	}
	else
	{
		file_close(f);
		lock_release(&system_file_lock);
		return process_execute(file_name);
	}
}

/* delete thread from its parent's child_list and change semaphore to wait it finish exit */
void sys_exit(int status)
{
	struct thread *cur = thread_current();
	cur->return_value = status;
	struct thread *parent = cur->parent;
	struct list *child_list = &parent->child_list;
	struct list_elem *child;
	for (child = list_begin(child_list); child != list_end(child_list); child = list_next(child))
	{
		struct child_thread *c = list_entry(child, struct child_thread, child_elem);
		if (c->tid == cur->tid)
		{
			c->is_waited = true;
			c->return_value = status;
		}
	}
	thread_exit();
}

  /* close and free specific process files
  by the given fd in the file list. Firstly,
  find fd in the list, then remove it. */
void 
sys_close(int fd)
{
	//struct file_describer *f = NULL;
	struct list* file_list1 = &thread_current()->file_list;
	struct list_elem *e;
	for (e = list_begin(file_list1); e != list_end(file_list1); e = list_next(e)){
		struct file_describer *fi = list_entry(e, struct file_describer, elem);
		if (fi->fd == fd){
			//f= fi;
			file_close(fi->ptr);
			list_remove(e);
    		free(fi);
    		break;
		}
	}
}

/* check whether the file is exist
when a file is open, it should be added into thread's 
file_list and add one on thread's file_count */
int sys_open(char *name){
	int value;
	lock_acquire(&system_file_lock);
	struct file *f = filesys_open(name);
	if (f){
		struct thread *cur = thread_current();
		struct file_describer *fi = malloc(sizeof(*fi));
		fi->ptr = f;
		fi->fd = cur->file_count;
		value = fi->fd;
		cur->file_count++;
		list_push_back(&cur->file_list, &fi->elem);
	}else{
		lock_release(&system_file_lock);
		return -1;
	}
	lock_release(&system_file_lock);
	return value;
}

/* read into buffer
find file with certain fd, write values in buffer into files */
int sys_read(int size, void *buffer, int fd){
	if (fd == 0){
		int i;
		uint8_t *buffer = buffer;
		for (i = 0; i < size; i++) {
			buffer[i] = input_getc();
		}
		return size;
	}else{
		struct file_describer *fi= find_file(fd);
		if (fi == NULL)
			return -1;
		else{
			return file_read(fi->ptr, buffer, size);
		}
	}
}

/* find the file with certain fd and then write into file */
int sys_write(int size, void *buffer, int fd){
	int value;
	if (fd == 1){
		putbuf(buffer, size);
		return size;
	}else{
		struct file_describer *fi = find_file(fd);
		if (fi == NULL)
			return -1;
		else{
			lock_acquire(&system_file_lock);
			value = file_write(fi->ptr, buffer, size);
			lock_release(&system_file_lock);
		}
	}

	return value;
}

